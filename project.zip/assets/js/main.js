const T = (name, fn) => { try { fn() } catch (e) { if (window?.LATELY_DEBUG) console.error(`[${name}]`, e) } }

T('backdrop-init', () => {
  const backdrop = document.getElementById('backdrop-layer')
  if (backdrop) {
    backdrop.classList.add('opacity-0', 'pointer-events-none')
    backdrop.classList.remove('opacity-100', 'blur')
  }
})

T('menu-burger', () => {
  const body = document.body
  const burgerWrap = document.querySelector('.nav-button-inner')
  const burgerIcons = burgerWrap ? burgerWrap.querySelectorAll('li') : []
  const btn = document.querySelector('.nav-button')

  const getMenu = () => document.querySelector('menu, .eo-mobile-menu, [data-menu]')

  function toggleIcons() {
    if (burgerIcons.length === 2) {
      burgerIcons[0].classList.toggle('opacity-0')
      burgerIcons[1].classList.toggle('opacity-0')
    }
  }

  function tintLeftBarGreen(on){
    const root = document.querySelector('nav.fixed')
    if(!root) return
    const wrap = root.querySelector('.w-full.h-full.absolute')
    if(!wrap || wrap.children.length < 2) return
    const [white, green] = wrap.children
    on ? (white.classList.add('opacity-0'), green.classList.remove('opacity-0'))
       : (green.classList.add('opacity-0'), white.classList.remove('opacity-0'))
  }

  function openMenu() {
    const m = getMenu(); if(!m) return
    body.classList.add('overflow-hidden')
    m.classList.remove('-translate-x-fuller')
    m.classList.add('translate-x-0')
    tintLeftBarGreen(true)
    toggleIcons()
  }

  function closeMenu() {
    const m = getMenu(); if(!m) return
    body.classList.remove('overflow-hidden')
    m.classList.add('-translate-x-fuller') // 48
    m.classList.remove('translate-x-0')
    tintLeftBarGreen(false)
    toggleIcons()
  }

  if (btn) {
    btn.addEventListener('click', () => {
      const m = getMenu(); if(!m) return
      const closed = !m.classList.contains('translate-x-0')
      closed ? openMenu() : closeMenu()
    })
  }

  ;(() => {
    const root = getMenu(); if(!root) return
    root.querySelectorAll('a').forEach(el => {
      el.addEventListener('click', () => {
        if (root.classList.contains('translate-x-0')) closeMenu()
      })
    })
  })()

  window.__openMenu = openMenu
  window.__closeMenu = closeMenu
})


T('work-drawer', () => {
  if (window.__caseBound3) return; window.__caseBound3 = true

  const body = document.body

  const ready = (fn) => (
    document.readyState === 'loading'
      ? document.addEventListener('DOMContentLoaded', fn, { once: true })
      : fn()
  )

  ready(function () {
    const work = document.getElementById('work')
    if (!work) return

    const escHandler = (e) => { if (e.key === 'Escape') closeDrawer() }

    function closeDrawer(node) {
      const drawer = node || document.querySelector('.case-drawer-mounted')
      if (!drawer) return
      drawer.classList.add('translate-x-full')
      drawer.classList.remove('translate-x-0')
      const done = () => { drawer.removeEventListener('transitionend', done); drawer.remove(); body.classList.remove('overflow-hidden') }
      drawer.addEventListener('transitionend', done)
      window.removeEventListener('keydown', escHandler)
    }

    const slugify = (s) => {
      if (!s) return null
      const first = s.trim().split(/\s+/)[0].replace(/[^\p{L}\p{N}-]+/gu, '')
      return first ? first.toLowerCase() : null
    }

    function metaFromNode(node) {
      let brand = node?.dataset.brand || ''
      let imgSrc = node?.dataset.img || ''
      let slug = node?.dataset.slug || ''

      if (!brand) {
        const img = node.querySelector('picture img[alt]')
        brand = (img?.getAttribute('alt') || '').trim()
        if (!brand) {
          const h4 = node.querySelector('h4')
          brand = h4 ? h4.textContent.trim() : ''
        }
      }
      if (!slug) slug = slugify(brand) || ''
      if (!imgSrc) {
        const imgOk = node.querySelector('picture img[src]')
        imgSrc = imgOk ? (imgOk.getAttribute('src') || '') : ''
      }
      if (!slug) return null
      return { href: `/${slug}/${slug}-brand-building`, caption: 'Brand Building', imgSrc }
    }

    function openDrawer(node, meta) {
      const opened = document.querySelector('.case-drawer-mounted')
      if (opened) closeDrawer(opened)

      const drawer = document.createElement('div')
      drawer.className = 'bg-white fixed bottom-0 right-0 top-0 w-full w-459px overflow-y-scroll case-drawer-mounted transform-gpu transition-transform duration-300 translate-x-full'
      drawer.style.zIndex = 60

      const topCloseDesk = document.createElement('div')
      topCloseDesk.className = 'px-2 pt-2 cursor-pointer lg:flex justify-end hidden'
      topCloseDesk.innerHTML = '<svg viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6"><rect x="7.39258" y="5.74976" width="16.2646" height="2.44393" transform="rotate(45 7.39258 5.74976)" fill="#0C7D4B"></rect><rect x="19.0146" y="7.31909" width="16.6613" height="2.38574" transform="rotate(135 19.0146 7.31909)" fill="#0C7D4B"></rect></svg>'
      topCloseDesk.onclick = () => closeDrawer(drawer)

      const shell = document.createElement('div')
      shell.className = 'lg:px-7 flex flex-col mb-10'

      const header = document.createElement('div')
      header.className = 'lg:pb-10 flex justify-between lg:justify-center items-center border-lightgray border-t border-b border-solid lg:border-none pt-0 lg:pt-10 h-10 lg:h-full'

      const logoSpan = document.createElement('span')
      logoSpan.className = 'relative w-28 lg:w-48 max-w-xs case-h2 pl-5 lg:pl-0 case-svg-span'
      const wrap = node.closest('.flex.flex-col.relative.w-full.cursor-pointer')
      const logoSvg = wrap?.nextElementSibling?.querySelector('.case-h2 svg') || node.querySelector('.case-h2 svg')
      if (logoSvg) logoSpan.innerHTML = logoSvg.outerHTML

      const closeMobile = document.createElement('div')
      closeMobile.className = 'px-2 py-2 cursor-pointer flex justify-end lg:hidden lg:border-none border-l border-lightgray border-solid'
      closeMobile.innerHTML = '<svg viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-6 h-6"><rect x="7.39258" y="5.74976" width="16.2646" height="2.44393" transform="rotate(45 7.39258 5.74976)" fill="#0C7D4B"></rect><rect x="19.0146" y="7.31909" width="16.6613" height="2.38574" transform="rotate(135 19.0146 7.31909)" fill="#0C7D4B"></rect></svg>'
      closeMobile.onclick = () => closeDrawer(drawer)

      header.appendChild(logoSpan)
      header.appendChild(closeMobile)

      const list = document.createElement('ul')
      list.className = 'flex flex-col px-5 lg:px-0 first-of-type:pt-5 lg:first-of-type:pt-0 mt-0'

      const li = document.createElement('li')
      li.className = 'flex lg:p-0 flex-col w-full items-center py-5'

      const aImg = document.createElement('a')
      aImg.href = meta.href
      aImg.className = 'relative w-full h-230 lg:h-275 overflow-hidden _cb_hover'
      const pic = document.createElement('picture')
      pic.className = 'absolute inset-0'
      const im = document.createElement('img')
      im.className = 'full v-lazy-image v-lazy-image-loaded'
      if (meta.imgSrc) im.src = meta.imgSrc
      pic.appendChild(im)
      aImg.appendChild(pic)

      const aText = document.createElement('a')
      aText.href = meta.href
      aText.className = 'inline-block lg:mt-4 mt-3 lg:pb-11 pb-8 flex flex-col justify-center lg:flex-row lg:items-center text-preview'
      aText.innerHTML = '<p class="ml-4 lg:m-0 font-sans text-center"><span class="font-serif">Brand</span> Building</p>'

      li.appendChild(aImg)
      li.appendChild(aText)
      list.appendChild(li)

      shell.appendChild(header)
      shell.appendChild(list)

      drawer.appendChild(topCloseDesk)
      drawer.appendChild(shell)
      document.body.appendChild(drawer)

      body.classList.add('overflow-hidden')
      drawer.offsetHeight
      drawer.classList.remove('translate-x-full')
      drawer.classList.add('translate-x-0')

      window.addEventListener('keydown', escHandler)
    }

    work.addEventListener('click', function (ev) {
      let node = ev.target.closest('._cb_hover.h-case, li')
      if (!node || !work.contains(node)) return
      if (node.tagName === 'LI' && !node.closest('ul.w-full.flex.flex-col')) return
      const marked = ev.target.closest('[data-case]')
      if (marked) node = marked
      ev.preventDefault()
      const meta = metaFromNode(node)
      if (!meta) return
      openDrawer(node, meta)
    }, { passive: false })
  })
})

T('work-view-switch', () => {
  function workView(btn, mode) {
    const section = btn?.closest('#work') || document.getElementById('work')
    if (!section) return

    const isList = mode === 'list'

    const switcher = btn?.closest('.work-button-container')
    if (switcher) {
      const [gridBtn, listBtn] = switcher.querySelectorAll('button')
      if (gridBtn && listBtn) {
        gridBtn.classList.toggle('text-white', !isList)
        gridBtn.classList.toggle('text-green', isList)
        listBtn.classList.toggle('text-white', isList)
        listBtn.classList.toggle('text-green', !isList)
        gridBtn.setAttribute('aria-pressed', String(!isList))
        listBtn.setAttribute('aria-pressed', String(isList))
      }
    }

    section.querySelectorAll('.work-button, .work-button-container').forEach(el => el.classList.toggle('is-list', isList))

    const $ = (sel, root=document) => root.querySelector(sel)
    const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel))
    const txt = (el) => (el ? el.textContent.trim() : '')

    const slugify = (s) => {
      if (!s) return ''
      const first = s.trim().split(/\s+/)[0].replace(/[^\p{L}\p{N}-]+/gu, '')
      return first ? first.toLowerCase() : ''
    }

    const pickImg = (root) => {
      const imgs = $$('picture img[src]', root)
      const ok = imgs.find(i => i.getAttribute('src') && i.getAttribute('src') !== '//:0')
      return ok ? ok.getAttribute('src') : ''
    }

    const extractFromGrid = (card) => {
      const imgEl = card.querySelector('picture img[alt]')
      const brandRaw = (imgEl?.getAttribute('alt') || '').trim() || txt(card.querySelector('h4'))
      const img = pickImg(card)
      const h2 = $('h2.case-h2', card)
      const h2HTML = h2 ? h2.outerHTML : ''
      const tag = $('.card-hover-bottom-content .uppercase, .card-hover-bottom-content .p-heading', card)
      const desc = $('.card-hover-bottom-content p:nth-of-type(2)', card)
      return { img, h2HTML, tag: txt(tag), desc: txt(desc), brand: brandRaw, slug: slugify(brandRaw) }
    }

    const extractFromList = (li) => {
      const img = pickImg(li)
      const h2 = $('h2.case-h2', li)
      const h2HTML = h2 ? h2.outerHTML : ''
      const tag = $('.tracking-tighter.text-sm.uppercase', li)
      const desc = $('.tracking-tighter.text-brand', li)
      const brandRaw = txt(h2) || (li.querySelector('picture img[alt]')?.getAttribute('alt') || '').trim()
      return { img, h2HTML, tag: txt(tag), desc: txt(desc), brand: brandRaw, slug: slugify(brandRaw) }
    }

    const buildListItem = ({img, h2HTML, tag, desc, brand, slug}) => {
      const li = document.createElement('li')
      li.className = 'px-5 lg:px-6'
      li.dataset.case = '1'
      if (brand) li.dataset.brand = brand
      if (slug) li.dataset.slug = slug
      if (img) li.dataset.img = img
      li.innerHTML = `
        <div class="group-hover-link border-t border-lightgrey border-solid py-7 lg:py-5 grid grid-cols-10">
          <div class="col-span-5 xl:col-span-4 flex items-center md:gap-10 xl:gap-20">
            <div class="case-image relative overflow-hidden shrink-0">
              <picture class="absolute inset-0"><img src="${img}" class="full v-lazy-image" alt="${brand || ''}"></picture>
            </div>
            ${h2HTML || '<h2 class="relative w-28 lg:w-48 max-w-xs case-h2"></h2>'}
          </div>
          <div class="w-full col-span-5 xl:col-span-6 flex items-center justify-between">
            <div class="flex flex-col gap-2">
              <p class="tracking-tighter text-sm uppercase">${tag || ''}</p>
              <p class="tracking-tighter text-brand">${desc || ''}</p>
            </div>
            <div class="flex justify-between items-center col-span-3 lg:col-span-2">
              <svg class="w-5 h-5 case-link"><use xlink:href="#svg-case-link"></use></svg>
            </div>
          </div>
        </div>`
      return li
    }

    const buildGridCard = ({img, h2HTML, tag, desc, brand, slug}) => {
      const wrap = document.createElement('div')
      wrap.className = 'flex flex-col relative w-full cursor-pointer'
      wrap.dataset.case = '1'
      if (brand) wrap.dataset.brand = brand
      if (slug) wrap.dataset.slug = slug
      if (img) wrap.dataset.img = img
      wrap.innerHTML = `
        <div class="block relative w-full h-case _cb_hover">
          <picture class="absolute inset-0 hidden lg:block">
            <img src="${img}" class="full v-lazy-image" alt="${brand || ''}">
          </picture>
          <picture class="absolute inset-0 lg:hidden">
            <img src="${img}" class="full v-lazy-image" alt="${brand || ''}">
          </picture>
          <div class="absolute inset-0 h-full w-full flex flex-col justify-between pointer-events-none card-hover-content">
            <div class="absolute inset-0 card-hover-bg"></div>
            <div class="w-full h-full relative text-white flex flex-col justify-between p-6 lg:p-12 lg:pr-3 pointer-events-none">
              <h4 class="text-2xl"></h4>
              <div class="flex flex-col gap-y-2.5 lg:gap-y-0 lg:flex-row lg:flex-wrap lg:items-center gap-2.5 card-hover-bottom-content">
                <p class="lg:normal-case uppercase p-heading">${tag || ''}</p>
                <svg width="6" height="6" viewBox="0 0 6 6" class="w-1.5 h-1.5 lg:block hidden"><circle cx="3" cy="3" r="3" fill="white"></circle></svg>
                <p>${desc || ''}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="flex justify-between items-center mt-4">
          ${h2HTML || '<h2 class="relative w-28 lg:w-48 max-w-xs case-h2"></h2>'}
          <svg class="w-6 h-6 lg:w-5 lg:h-5 mr-4"><use xlink:href="#svg-case-link"></use></svg>
        </div>`
      return wrap
    }

    const GRID_SEL = '.eo-grid'
    const LIST_SEL = '.eo-list'

    let gridContainer = section.querySelector(GRID_SEL)
    let listContainer = section.querySelector(LIST_SEL)

    if (isList) {
      if (!listContainer) {
        if (!gridContainer) {
          gridContainer = section.querySelector('.grid.gap-y-11') || section.querySelector('.grid')
        }
        if (!gridContainer) return
        const cards = section.querySelectorAll('.flex.flex-col.relative.w-full.cursor-pointer')
        const data = Array.from(cards).map(extractFromGrid)
        const ul = document.createElement('ul')
        ul.className = `w-full flex flex-col eo-list`
        data.forEach(d => ul.appendChild(buildListItem(d)))
        gridContainer.replaceWith(ul)
      }
    } else {
      if (!gridContainer) {
        if (!listContainer) {
          listContainer = section.querySelector(LIST_SEL) || section.querySelector('ul.w-full.flex.flex-col') || section.querySelector('ul')
        }
        if (!listContainer) return
        const items = Array.from(listContainer.querySelectorAll(':scope > li'))
        const data = items.map(extractFromList)
        const grid = document.createElement('div')
        grid.className = 'grid gap-y-11 px-5 lg:px-6 pb-5 lg:grid-cols-2 lg:gap-x-4 lg:gap-y-8 eo-grid'
        data.forEach(d => grid.appendChild(buildGridCard(d)))
        listContainer.replaceWith(grid)
      }
    }
  }

  window.workView = (btn, mode) => { try { workView(btn, mode) } catch(e) { if (window?.LATELY_DEBUG) console.error('[workView]', e) } }
})

T('newsletter-eye', () => {
  const zone = document.querySelector('.eye-zone, [data-open-newsletter]')
  const tray = document.querySelector('.newsletter-tray')
  const closeBtn = tray?.querySelector('[data-close-newsletter]') || document.querySelector('[data-close-newsletter]')
  const cursor = document.querySelector('.custom-cursor')
  const eye = document.querySelector('g#eye')
  const outer = eye?.querySelector('circle:nth-child(1)')
  const svg = eye?.closest('svg')

  if(!zone||!tray||!cursor){ return }

  if(!tray.classList.contains('translate-x-full') && !tray.classList.contains('translate-x-0')){
    tray.classList.add('transform-gpu','translate-x-full')
  }

  let over=false, mx=0, my=0, ex=0, ey=0
  const baseTF = eye?.getAttribute('transform') || ''
  const maxShift = 22

  function toSVG(x,y){
    if(!svg?.getScreenCTM) return {x,y}
    const pt = svg.createSVGPoint(); pt.x=x; pt.y=y
    const m = svg.getScreenCTM(); if(!m) return {x,y}
    return pt.matrixTransform(m.inverse())
  }

  function insideZone(x,y){
    const r = zone.getBoundingClientRect()
    return x>=r.left && x<=r.right && y>=r.top && y<=r.bottom
  }

  function eyeTick(){
    if(over && eye && outer){
      const cx = parseFloat(outer.getAttribute('cx'))||0
      const cy = parseFloat(outer.getAttribute('cy'))||0
      const p = toSVG(mx,my)
      const dx = p.x - cx, dy = p.y - cy
      const len = Math.hypot(dx,dy)||1
      const k = Math.min(maxShift,len)/len
      const tx = dx*k, ty = dy*k
      ex += (tx-ex)*0.18
      ey += (ty-ey)*0.18
      eye.setAttribute('transform', `${baseTF} translate(${ex.toFixed(2)} ${ey.toFixed(2)})`)
    }
    requestAnimationFrame(eyeTick)
  }

  function showCursor(){
    if(over) return
    over = true
    document.body.style.cursor = 'none'
    cursor.classList.remove('opacity-0')
  }

  function hideCursor(){
    if(!over) return
    over = false
    document.body.style.cursor = ''
    cursor.classList.add('opacity-0')
    if(eye) { eye.setAttribute('transform', baseTF); ex=0; ey=0 }
  }

  function onMove(e){
    mx = e.clientX; my = e.clientY
    cursor.style.left = mx + 'px'
    cursor.style.top  = my + 'px'
    if(!over && insideZone(mx,my)) showCursor()
  }

  function openTray(){
    tray.classList.remove('translate-x-full')
    tray.classList.add('translate-x-0')
  }

  function closeTray(){
    tray.classList.remove('translate-x-0')
    tray.classList.add('translate-x-full')
    hideCursor()
  }

  function onScroll(){
    if(over && !insideZone(mx,my)) hideCursor()
  }

  zone.addEventListener('pointerenter', showCursor, {passive:true})
  zone.addEventListener('pointerleave', hideCursor, {passive:true})
  zone.addEventListener('pointermove', onMove, {passive:true})
  zone.addEventListener('click', openTray)
  closeBtn?.addEventListener('click', (e)=>{ e.preventDefault(); closeTray() })

  document.addEventListener('scroll', onScroll, {passive:true})
  window.addEventListener('scroll', onScroll, {passive:true})
  window.addEventListener('blur', hideCursor, {passive:true})

  cursor.style.left='0px'; cursor.style.top='0px'
  requestAnimationFrame(eyeTick)
})

T('lately-core', () => {
  window.LATELY_DEBUG = true

  const log = (() => {
    const enabled = () => !!window.LATELY_DEBUG
    const tag = '[lately]'
    return {
      info: (...a) => enabled() && console.info(tag, ...a),
      warn: (...a) => enabled() && console.warn(tag, ...a),
      error: (...a) => enabled() && console.error(tag, ...a),
      group: (label) => enabled() && console.group(tag, label),
      groupEnd: () => enabled() && console.groupEnd()
    }
  })()

  const SCROLL_LOCK_TARGET = document.documentElement

  function lockScroll() {
    SCROLL_LOCK_TARGET.classList.add('overflow-hidden')
    document.body.style.overflow = 'hidden'
    log.info('scroll locked')
  }

  function unlockScroll() {
    SCROLL_LOCK_TARGET.classList.remove('overflow-hidden')
    document.body.style.overflow = ''
    log.info('scroll unlocked')
  }

  function findTemplateById(id) {
    const t = document.querySelector(`template[data-id-lately-content="${CSS.escape(id)}"]`)
    log.info('findTemplateById:', id, '=>', !!t ? 'found' : 'NOT found')
    return t
  }

  function closeCurrentModal() {
    const overlay = document.querySelector('#backdrop-layer')
    if (!overlay) {
      log.info('close: nothing to close')
      return
    }
    overlay.remove()
    document.removeEventListener('keydown', onEsc)
    unlockScroll()
    log.info('modal closed')
  }

  function onEsc(e) {
    if (e.key === 'Escape') {
      log.info('ESC pressed -> close')
      closeCurrentModal()
    }
  }

  function throttle(fn, wait) {
    let last = 0, t
    return function (...args) {
      const now = Date.now()
      const rem = wait - (now - last)
      if (rem <= 0) {
        last = now
        fn.apply(this, args)
      } else {
        clearTimeout(t)
        t = setTimeout(() => {
          last = Date.now()
          fn.apply(this, args)
        }, rem)
      }
    }
  }

  function initProgressBar(overlayEl) {
    const bar = overlayEl.querySelector('.progress-bar .filled-bar')
    if (!bar) {
      log.info('progress bar: not present')
      return
    }
    log.info('progress bar: binding')

    const scroller = overlayEl
    const update = throttle(() => {
      const max = scroller.scrollHeight - scroller.clientHeight
      const pct = max > 0 ? (scroller.scrollTop / max) * 100 : 0
      bar.style.width = pct + '%'
      if (Math.round(pct) % 10 === 0) log.info('progress:', pct.toFixed(1) + '%')
    }, 150)

    scroller.addEventListener('scroll', update, { passive: true })
    requestAnimationFrame(update)
  }

  function bindCloseHandlers(overlayEl) {
    overlayEl.addEventListener('click', (e) => {
      if (e.target === overlayEl) {
        log.info('backdrop click -> close')
        closeCurrentModal()
      }
    })

    const closeBtns = overlayEl.querySelectorAll('#button-layer, .close, #button-end')
    closeBtns.forEach(btn => btn && btn.addEventListener('click', () => {
      log.info('close button click -> close')
      closeCurrentModal()
    }))
    log.info('close handlers bound:', closeBtns.length, 'button(s)')
  }

  function focusFirstClose(overlayEl) {
    const closeBtn = overlayEl.querySelector('#button-layer, .close, #button-end')
    if (closeBtn && typeof closeBtn.focus === 'function') {
      closeBtn.focus()
      log.info('focus set to close button')
    }
  }

  function openModalById(id) {
    log.group(`open modal ${id}`)
    const tpl = findTemplateById(id)
    if (!tpl) {
      log.warn('open aborted: template not found for id', id)
      log.groupEnd()
      return
    }

    closeCurrentModal()
    log.info('previous modal (if any) closed')

    const t0 = performance.now()
    const frag = tpl.content.cloneNode(true)
    document.body.appendChild(frag)
    const overlayEl = document.querySelector('#backdrop-layer')

    if (!overlayEl) {
      log.error('mount failed: #backdrop-layer not found in cloned content')
      log.groupEnd()
      return
    }

    const dt = (performance.now() - t0).toFixed(1)
    log.info('mounted in', dt, 'ms')

    lockScroll()
    bindCloseHandlers(overlayEl)
    initProgressBar(overlayEl)
    document.addEventListener('keydown', onEsc)
    focusFirstClose(overlayEl)

    log.groupEnd()
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.initiatives-module')
    if (!btn) return
    const host = btn.closest('[data-id-lately]')
    if (!host) return
    e.preventDefault()
    const id = host.getAttribute('data-id-lately')
    log.group('card click')
    log.info('data-id-lately =', id)
    openModalById(id)
    log.groupEnd()
  })

  window.Lately = { open: openModalById, close: closeCurrentModal }
  log.info('boot complete, ready')
})

T('lately-slider', () => {
  function initLatelySlider(root) {
    const slider = root.querySelector('.lately-slider')
    if (!slider) return
    const dots = slider.querySelectorAll('[data-index]')
    const slides = slider.querySelectorAll('.slides .slide')
    if (!slides.length) return
    let currentIndex = 0

    function setDotState(activeIdx) {
      dots.forEach((dot, i) => {
        const active = i === activeIdx
        dot.classList.toggle('bg-green', active)
        dot.classList.toggle('bg-white', !active)
        dot.setAttribute('aria-current', active ? 'true' : 'false')
      })
    }

    function showSlide(idx, opts = { from: currentIndex }) {
      const total = slides.length
      const next = ((idx % total) + total) % total
      slides.forEach((slide, i) => {
        const isActive = i === next
        slide.style.display = isActive ? '' : 'none'
        slide.setAttribute('aria-hidden', isActive ? 'false' : 'true')
      })
      if (dots.length) setDotState(next)
      currentIndex = next
    }

    slides.forEach((s, i) => {
      s.style.display = i === 0 ? '' : 'none'
      s.setAttribute('aria-hidden', i === 0 ? 'false' : 'true')
    })
    if (dots.length) setDotState(0)

    dots.forEach((dot) => {
      dot.addEventListener('click', (e) => {
        const idx = parseInt(dot.getAttribute('data-index'), 10)
        if (!Number.isNaN(idx)) showSlide(idx)
      })
      dot.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault()
          const idx = parseInt(dot.getAttribute('data-index'), 10)
          if (!Number.isNaN(idx)) showSlide(idx)
        }
      })
      dot.setAttribute('tabindex', '0')
      dot.setAttribute('role', 'button')
      dot.setAttribute('aria-label', `Go to slide ${parseInt(dot.getAttribute('data-index'), 10) + 1}`)
    })

    slider.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowRight') showSlide(currentIndex + 1)
      else if (e.key === 'ArrowLeft') showSlide(currentIndex - 1)
    })

    slides.forEach((s) => {
      s.addEventListener('click', (e) => {
        if (e.target && e.target.closest('a')) return
        showSlide(currentIndex + 1)
      })
    })

    slider.__lately = {
      next: () => showSlide(currentIndex + 1),
      prev: () => showSlide(currentIndex - 1),
      go: (i) => showSlide(i),
      get index() { return currentIndex },
      get count() { return slides.length }
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    const roots = document.querySelectorAll('[card="latelySlider"]')
    roots.forEach(initLatelySlider)
  })
})

T('phase-nav-A', () => {
  const nav = document.querySelector('.phase-nav')
  if (!nav) return
  const trackHost = nav.querySelector('.relative.py-5') || nav.querySelector('.relative')
  const dot = nav.querySelector('.w-2.h-2.rounded-full') || (() => { const e=document.createElement('div'); e.className='absolute w-2 h-2 bg-black rounded-full top-1/3 transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ease-out z-5'; e.style.left='0px'; trackHost.appendChild(e); return e })()
  const btnsAll = Array.from(nav.querySelectorAll('button'))
  const phaseBtns = btnsAll.filter(b => /Phase\s+\d/i.test(b.textContent))
  const sections = [1,2,3,4].map(n => document.getElementById(`phase-${n}`)).filter(Boolean)
  if (phaseBtns.length !== sections.length) return

  let centers = []
  const pxLeftOf = el => {
    const r = el.getBoundingClientRect()
    const p = trackHost.getBoundingClientRect()
    return r.left - p.left + r.width / 2
  }
  const measure = () => { centers = phaseBtns.map(pxLeftOf) }

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v))
  const lerp = (a, b, t) => a + (b - a) * t

  const setActive = idx => {
    phaseBtns.forEach((b, i) => {
      const circle = b.querySelector('svg circle')
      const label = b.querySelector('span')
      if (circle) circle.setAttribute('fill', i === idx ? '#000000' : '#FFFFFF')
      if (label) label.style.opacity = i === idx ? '1' : '0.3'
    })
  }

  const progressFromScroll = () => {
    const container = document.getElementById('phases-container')
    if (container) {
      const r = container.getBoundingClientRect()
      const total = r.height - window.innerHeight
      const sc = clamp((0 - r.top) / (total <= 0 ? 1 : total), 0, 1)
      return sc
    } else if (sections.length) {
      const docTop = sections[0].offsetTop
      const docBottom = sections[sections.length - 1].offsetTop + sections[sections.length - 1].offsetHeight - window.innerHeight
      const scY = clamp((window.scrollY - docTop) / Math.max(1, docBottom - docTop), 0, 1)
      return scY
    }
    return 0
  }

  const moveDot = t => {
    if (!centers.length) measure()
    const x = lerp(centers[0], centers[centers.length - 1], t)
    dot.style.left = x + 'px'
  }

  const io = new IntersectionObserver(entries => {
    let best = { i: 0, r: 0 }
    entries.forEach(e => {
      const i = sections.indexOf(e.target)
      if (e.intersectionRatio > best.r) best = { i, r: e.intersectionRatio }
    })
    if (best.r > 0) setActive(best.i)
  }, { threshold: [0.25, 0.5, 0.6, 0.75, 0.9] })

  sections.forEach(s => io.observe(s))

  const onScroll = () => { moveDot(progressFromScroll()) }
  const onResize = () => { measure(); onScroll() }

  phaseBtns.forEach((b, i) => {
    b.addEventListener('click', e => {
      e.preventDefault()
      const sec = sections[i]
      if (!sec) return
      const top = sec.getBoundingClientRect().top + window.scrollY
      window.scrollTo({ top, behavior: 'smooth' })
    })
  })

  measure()
  setActive(0)
  onScroll()
  window.addEventListener('scroll', onScroll, { passive: true })
  window.addEventListener('resize', onResize)
})

T('phase-nav-B', () => {
  document.querySelectorAll('.phase-nav').forEach(el=>{
    el.style.opacity='1'
    el.style.transform='translateY(0)'
    el.classList.remove('nav-fade-out')
  })
})

T('phase-nav-progress', () => {
  const nav = document.querySelector('.phase-nav')
  if (!nav) return
  const trackHost = nav.querySelector('.relative.py-5') || nav.querySelector('.relative')
  const dot = nav.querySelector('.w-2.h-2.rounded-full')
  const btnsAll = Array.from(nav.querySelectorAll('button'))
  const phaseBtns = btnsAll.filter(b => /Phase\s+\d/i.test(b.textContent))
  const sections = [1,2,3,4].map(n => document.getElementById(`phase-${n}`)).filter(Boolean)
  if (!dot || phaseBtns.length !== sections.length) return

  const colors = ['#0C7D4B','#2C4D83','#C92A2A','yellow']
  let centers = []

  const measure = () => {
    centers = phaseBtns.map(b => {
      const r = b.getBoundingClientRect()
      const p = trackHost.getBoundingClientRect()
      return r.left - p.left + r.width / 2
    })
  }

  const setPassed = count => {
    phaseBtns.forEach((b, i) => {
      const c = b.querySelector('svg circle')
      const l = b.querySelector('span')
      if (c) c.setAttribute('fill', i < count ? colors[i] : '#FFFFFF')
      if (l) l.style.opacity = i < count ? '1' : '0.3'
    })
  }

  const scrollProgress = () => {
    const first = sections[0].offsetTop
    const last = sections.at(-1).offsetTop + sections.at(-1).offsetHeight - innerHeight
    return Math.max(0, Math.min(1, (scrollY - first) / (last - first || 1)))
  }

  const moveDot = t => {
    const x = centers[0] + (centers.at(-1) - centers[0]) * t
    dot.style.left = x + 'px'
  }

  const countPassed = () => {
    const y = scrollY + innerHeight * 0.4
    let k = 0
    for (let i = 0; i < sections.length; i++) if (y >= sections[i].offsetTop) k++
    return Math.max(0, Math.min(sections.length, k))
  }

  const onScroll = () => {
    moveDot(scrollProgress())
    setPassed(countPassed())
  }

  addEventListener('scroll', onScroll, { passive: true })
  addEventListener('resize', () => { measure(); onScroll() })

  measure()
  setPassed(0)
  onScroll()
})

T('nav-contacts-accordion', () => {
  document.addEventListener('DOMContentLoaded', () => {
    const sets = [...document.querySelectorAll('.nav__link .contact-info')].map(info => ({
      item: info.closest('.nav__link'),
      info,
      trigger: info.closest('.nav__link').querySelector('.flex.flex-row.justify-between.pb-2.items-center') || info.closest('.nav__link')
    })).filter(s => s.item && s.info && s.trigger)

    const closeAll = except => {
      sets.forEach(({ item, info }) => {
        if (item === except) return
        item.classList.remove('on')
        info.classList.remove('on')
        item.setAttribute('aria-expanded', 'false')
      })
    }

    sets.forEach(({ item, info, trigger }) => {
      item.setAttribute('aria-expanded', item.classList.contains('on') ? 'true' : 'false')
      trigger.setAttribute('tabindex', '0')

      const toggle = () => {
        const willOpen = !item.classList.contains('on')
        closeAll(willOpen ? item : null)
        item.classList.toggle('on', willOpen)
        info.classList.toggle('on', willOpen)
        item.setAttribute('aria-expanded', willOpen ? 'true' : 'false')
      }

      item.addEventListener('click', e => {
        if (e.target.closest('.contact-info')) return
        if (!e.target.closest('.flex.flex-row.justify-between.pb-2.items-center')) return
        toggle()
      })

      trigger.addEventListener('keydown', e => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault()
          toggle()
        }
      })

      info.addEventListener('click', e => e.stopPropagation())
    })

    document.addEventListener('click', e => {
      if (![...sets.map(s => s.item)].some(el => el.contains(e.target))) closeAll()
    })

    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAll() })
  })
})

T('observe-fade-in', () => {
  setTimeout(() => {
    document.querySelectorAll('[data-observe]').forEach(el => {
      el.style.setProperty('opacity', '1', 'important')
    })
  }, 1000)
})

T('brandText-colors', () => {
  const colors = ["#2e8b57", "#2563eb", "#b22222", "#daa520"]
  const el = document.getElementById("brandText")
  if (!el) return
  const text = el.textContent.trim()
  el.innerHTML = ""
  ;[...text].forEach((ch, i) => {
    const span = document.createElement("span")
    span.textContent = ch
    span.style.color = colors[i % colors.length]
    el.appendChild(span)
  })
  function fitText() { el.style.fontSize = "200px" }
  fitText()
  window.addEventListener("resize", fitText)
})
